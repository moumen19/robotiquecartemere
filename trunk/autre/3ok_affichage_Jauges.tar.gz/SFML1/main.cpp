
////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
//#include <SFML/Graphics.hpp>
//#include <SFML/Window.hpp>
//#include <SFML/System.hpp>
//#include <iostream>

#include "display.h"

////////////////////////////////////////////////////////////
/// Entry point of application
///
/// \return Application exit code
///
////////////////////////////////////////////////////////////

int main()
{

    display a;

    //* Sert à rien ici, just pour balayer tous les capteurs deja définis
    std::map<int , float> tab;
    tab[0x90] = 0;
    tab[0x30] = 100;
    tab[0x32] = 100;
    tab[0x34] = 100;
    tab[0x36] = 100;
    tab[0x38] = 100;
    tab[0x3A] = 100;
    tab[0x3C] = 100;
    tab[0x3E] = 100;
    tab[0x50] = 100;
    tab[0x53] = 100;
    tab[0x56] = 100;
    tab[0x59] = 100;
    tab[0x70] = 100;
    tab[0x72] = 100;//*/

// Ahaha
while(1)
{
    for(int i=2;i<windowSizeH;i=i+100)
    {
         // balaye toute les Key de la map
        for(std::multimap<int, float>::iterator it=tab.begin() ; it!=tab.end() ; ++it)
        {
            a.setSensorDistance(it->first,i);
        }
        usleep(500000);
    }

       for(int i=2;i<windowSizeH;i=i+100)
    {
         // balaye toute les Key de la map
        for(std::multimap<int, float>::iterator it=tab.begin() ; it!=tab.end() ; ++it)
        {
            a.setSensorDistance(it->first,windowSizeH-i);
            a.setSensorDistance(0x90,0);
        }
        usleep(100000);
    }
}


    return EXIT_SUCCESS;
}
